/*
 * Presenter.c
 *
 *  Created on: Jun 24, 2025
 *      Author: rhoblack
 */
#include "Presenter.h"
#include <string.h>
#include <stdio.h>
#include "usart.h"

// 수업시간에 만든 함수
static void Presenter_DispTimeWatch(watch_t watchData);
static void Presenter_DispStopWatch(watch_t watchData);
static void Presenter_DispFndTimeWatch(watch_t watchData);
static void Presenter_DispFndStopWatch(watch_t watchData);
static void Presenter_DispMonitorTimeWatch(watch_t watchData);
static void Presenter_DispMonitorStopWatch(watch_t watchData);
static watch_t dispData = {TIME_WATCH, 12, 0, 0, 0};

// 프로젝트 함수
void Presenter_DispFeedStateFND(void);
void Presenter_DispFeedStateLCD(void);
void Presenter_DispFeedStateUART(void);

extern time_TypeDef time_feed_remain;
extern ControlFlag_TypeDef controlFlag;

outputData_TypeDef feed_Output_Data = {0};
ControlFlag_TypeDef feed_Output_Flag = {0};


void Presenter_Excute()
{
   feed_Output_Data = *Controller_GetOutput();   // 역참조하여 구조체 값 복사
   feed_Output_Flag = *Controller_GetFlags();    // 역참조하여 구조체 값 복사
   Presenter_DispFeedStateFND();
   Presenter_DispFeedStateLCD();
   // Presenter_DispFeedStateUART();

   if (fsm_state == FEED_MODE)
   {
      HAL_Delay(5000);
      controlFlag.feedtimeoutFlag = 0;
   }

}


void Presenter_DispFeedStateFND()
{
   switch (fsm_state)
   {
   case INPUT_MODE:
      if (input_state == PERIOD_IDLE) {
         FND_WriteData(feed_Output_Data.feed_period); // 단위: 분
      }
      else if (input_state == AMOUNT_IDLE) {
         FND_WriteData(feed_Output_Data.feed_amount); // 단위: g
      }
      break;

   case WAIT_MODE:
      FND_WriteData(time_feed_remain.min * 100 + time_feed_remain.sec);
      break;

   case FEED_MODE:
      FND_WriteData(8888); // 사료 배급 중이라는 표시
      break;
   }
}


void Presenter_DispFeedStateLCD()
{
   char str0[32];
   char str1[32];


   switch (fsm_state)
   {
   case INPUT_MODE:
      sprintf(str0, "TIME: %lu min", feed_Output_Data.feed_period);
      sprintf(str1, "AMOUNT: %lu mode", feed_Output_Data.feed_amount);

      break;

   case WAIT_MODE:
      sprintf(str0,  "T:%02d:%02dM:%lu(5/10)", time_feed_remain.min, time_feed_remain.sec,feed_Output_Data.feed_amount);
      sprintf(str1, "T/H: 25.6 / 50.3");

      break;

   case FEED_MODE:
      LCD_writeStringXY(0, 0, "                ");  // 16자 기준
      LCD_writeStringXY(1, 0, "                ");
      HAL_Delay(500);
      sprintf(str0, "FEED TIME!!");
      sprintf(str1, "YUMMY~~~~");
      break;
   }

   LCD_writeStringXY(0, 0, str0);
   LCD_writeStringXY(1, 0, str1);

}



void Presenter_DispFeedStateUART()
{
   char str[100];


   switch (fsm_state)
   {
   case INPUT_MODE:
      if (input_state == PERIOD_IDLE) {
         sprintf(str, "[입력모드] 주기 설정: %lu 분\n", feed_Output_Data.feed_period);
      }
      else if (input_state == AMOUNT_IDLE) {
         sprintf(str, "[입력모드] 양 설정: %lu g\n", feed_Output_Data.feed_amount);
      }
      break;

   case WAIT_MODE:
      sprintf(str, "[대기모드] 남은 시간: %02d:%02d\n", time_feed_remain.min, time_feed_remain.sec);
      break;

   case FEED_MODE:
      sprintf(str, "[배급모드] 사료 배급 중...\n");
      break;
   }

   HAL_UART_Transmit(&huart2, (uint8_t*)str, strlen(str), 1000);
}














void Presenter_Init()
{
   LCD_Init(&hi2c1);
   Sound_Init();
   motor_Init(&htim1, TIM_CHANNEL_1);
   motor_SetDuty(80);
}

void Presenter_OutData(watch_t watchData)
{
   memcpy(&dispData, &watchData, sizeof(watch_t));
}




void Presenter_DispTimeWatch(watch_t watchData)
{
   Presenter_DispFndTimeWatch(watchData);
   Presenter_DispMonitorTimeWatch(watchData);
}

void Presenter_DispStopWatch(watch_t watchData)
{
   Presenter_DispFndStopWatch(watchData);
   Presenter_DispMonitorStopWatch(watchData);
}



void Presenter_DispFndTimeWatch(watch_t watchData)
{
   FND_WriteData(watchData.hour*100 + watchData.min);

   FND_WriteDp(FND_DP_1000|FND_DP_10|FND_DP_1, FND_DP_OFF);

   if (watchData.msec < 500) {
      FND_WriteDp(FND_DP_100, FND_DP_ON);
   }
   else {
      FND_WriteDp(FND_DP_100, FND_DP_OFF);
   }
}

void Presenter_DispFndStopWatch(watch_t watchData)
{
   FND_WriteData((watchData.min % 10 * 1000) + (watchData.sec * 10) + (watchData.msec/100));

   FND_WriteDp(FND_DP_100|FND_DP_1, FND_DP_OFF);

   if (watchData.msec%100 < 50) {
      FND_WriteDp(FND_DP_10, FND_DP_ON);
   }
   else {
      FND_WriteDp(FND_DP_10, FND_DP_OFF);
   }

   if (watchData.msec < 500) {
      FND_WriteDp(FND_DP_1000, FND_DP_ON);
   }
   else {
      FND_WriteDp(FND_DP_1000, FND_DP_OFF);
   }
}

void Presenter_DispMonitorTimeWatch(watch_t watchData)
{
   char str[50];
   sprintf(str,"Time Watch : %02d:%02d:%02d.%03d\n", watchData.hour, watchData.min, watchData.sec, watchData.msec);
   HAL_UART_Transmit(&huart2, (uint8_t *)str, strlen(str), 1000);
}

void Presenter_DispMonitorStopWatch(watch_t watchData)
{
   char str[50];
   sprintf(str,"Stop Watch : %02d:%02d:%02d.%03d\n", watchData.hour, watchData.min, watchData.sec, watchData.msec);
   HAL_UART_Transmit(&huart2, (uint8_t *)str, strlen(str), 1000);
}

void Presenter_DispLCDStopWatch(watch_t watchData)
{
   char str[50];
   sprintf(str, "SW : %02d:%02d:%02d.%03d\n", watchData.hour, watchData.min, watchData.sec, watchData.msec);
   LCD_writeStringXY(0,  0, str);
}

void Presenter_DispLCDTimeWatch(watch_t watchData)
{
   char str[50];
   sprintf(str, "TW : %02d:%02d:%02d.%03d\n", watchData.hour, watchData.min, watchData.sec, watchData.msec);
   LCD_writeStringXY(1,  0, str);
}








