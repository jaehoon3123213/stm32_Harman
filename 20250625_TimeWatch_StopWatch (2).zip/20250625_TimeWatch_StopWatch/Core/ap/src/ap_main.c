/*
 * ap_main.c
 *
 *  Created on: Jun 19, 2025
 *      Author: rhoblack
 */

#include "ap_main.h"
#include "dht11.h"

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if(htim->Instance == TIM2) {
		FND_DispDataCallBack();

		TimeWatch_IncTimeCallBack();
		StopWatch_IncTimeCallBack();
	}
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if (huart->Instance == USART2) {
		Listener_UartCallBack();
	}
}


void DWT_Init(void)
{
    // DWT 활성화 (1us 단위 딜레이 가능하게 설정)
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CYCCNT = 0;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
}


int ap_main()
{

	HAL_TIM_Base_Start_IT(&htim2);


	LCD_writeStringXY(0, 0, "Hello World!");
	LCD_writeStringXY(1, 0, "Hello STM32!");
	motor_Start();
	dht_start();
	while(1)
	{

	}

	return 0;
}

void ap_init()
{
	Listener_Init();
	Presenter_Init();
	Sound_Init();
	DWT_Init();
	motor_Init(&htim1, TIM_CHANNEL_1);
	motor_SetDuty(80);
	DHT11_Init(GPIOA, GPIO_PIN_6);
//	Sound_PowerOn();
}



