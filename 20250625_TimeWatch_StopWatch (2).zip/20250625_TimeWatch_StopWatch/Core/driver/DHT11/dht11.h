/*
 * dht11.h
 *
 *  Created on: Jun 26, 2025
 *      Author: kccistc
 */

#ifndef DRIVER_DHT11_DHT11_H_
#define DRIVER_DHT11_DHT11_H_

#include "tim.h"
#include "stm32f4xx_hal.h"

void DHT11_Init(GPIO_TypeDef * port, uint16_t GPIO_Pin);
void Set_Pin_Output();
void Set_Pin_Input();
void dht_start();
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim);

#endif /* DRIVER_DHT11_DHT11_H_ */
